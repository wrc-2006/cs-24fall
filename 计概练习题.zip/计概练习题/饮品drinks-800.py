n=int(input())
p=list(map(int,input().split()))
print(sum(p)/n)
