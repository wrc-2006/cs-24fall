x,y,z=map(int,input().split())
print(max(x,y,z)-min(x,y,z))
