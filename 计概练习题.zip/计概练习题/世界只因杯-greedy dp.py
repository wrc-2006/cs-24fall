n=int(input())
radius=[int(x) for x in input().split()]



