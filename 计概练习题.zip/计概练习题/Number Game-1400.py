t=int(input())
for _ in range(t):
    n=int(input())
    a=sorted([int(x) for x in input().split()])
    
    