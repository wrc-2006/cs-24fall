m=input()
n=input()
if m.lower() > n.lower():
    print(1)
elif m.lower()<n.lower():
    print(-1)
else:
    print(0)
