n=int(input())
lst=[]
for i in range(4):
    lst.append(input())
for _ in range(n):
    word=input()


