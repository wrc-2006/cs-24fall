n=int(input())
s=[int(x) for x in input().split()]
lst=[]
for i in range(len(s)):
     