m=int(input())
if m>2 and m%2==0:
    print('YES')
else:
    print('NO')

